package com.example.weatherapop

import android.content.Intent
import android.content.SharedPreferences.Editor
import android.icu.lang.UCharacter.NumericType
import android.os.Bundle
import android.text.InputType
import android.widget.Button
import android.widget.EdgeEffect
import android.widget.EditText
import android.widget.NumberPicker
import android.widget.TextSwitcher
import android.widget.TextView
import android.widget.Toast
import android.widget.Toolbar
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import com.google.android.material.textfield.TextInputEditText
import org.w3c.dom.Text
import java.text.NumberFormat
import kotlin.system.exitProcess

class WForecastActivity2 : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_wforecast2)

//variables declaration
        var TextWeeklyDays: TextView
        var TextInputTemp: TextView


        val weeklyDaysNumber: TextView = findViewById(R.id.text_days)
        val temperatureRecord: TextView = findViewById(R.id.txt_temps)
        val abuttonNext: Button = findViewById(R.id.btn_next)
        var abuttonOut: Button = findViewById(R.id.btn_out)

// fcunctions created for buttons
        abuttonNext.setOnClickListener {
        }

        val weeklyDaysNumberArray = temperatureRecord.text.toString().split(",").map { it.trim() }.toTypedArray()
        val temperatureRecordArray = temperatureRecord.text.toString().split(",").map { it.trim() }.toTypedArray()


        val intent7 = Intent(this, TemperatureActivity::class.java).apply {
            putExtra("ArrayweeklyDaysNumber", weeklyDaysNumberArray)
            putExtra("ArraytemperatureRecord", temperatureRecordArray)
        }
// button to go back to exit app
        abuttonOut.setOnClickListener {
            exitProcess(0)
        }

    }
}