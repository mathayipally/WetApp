package com.example.weatherapop

import android.content.Intent
import android.os.Bundle
import android.widget.Button
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import kotlin.system.exitProcess

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val ibuttonBegin : Button = findViewById(R.id.btn_begin)
        val ibuttonBack : Button = findViewById(R.id.btn_back)

        ibuttonBegin.setOnClickListener{

            // button clicked to navigate the fist screen

            val intent4= Intent(this,WForecastActivity2::class.java)

            startService(intent4)

        }
// butto clicked to exit
        ibuttonBack.setOnClickListener{
            exitProcess(0)
        }
    }
}