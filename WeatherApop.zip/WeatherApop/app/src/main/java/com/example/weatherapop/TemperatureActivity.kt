package com.example.weatherapop

import android.content.Intent
import android.os.Bundle
import android.widget.Button
import android.widget.TextView
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.text.util.LocalePreferences.FirstDayOfWeek.Days
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat

class TemperatureActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_temperature)

// Arrays populated
        val weeklyDaysNumberArray: TextView =findViewById(R.id.txt_showdays)
        val temperatureRecordArray: TextView = findViewById(R.id.txt_showtemp)
        val viewbutton : Button = findViewById(R.id.btn_view)

        viewbutton.setOnClickListener{


            val weeklyDaysNumberArray: Array<String= weeklyDaysNumberArray.text.toString().split(",").map { it.trim() }.toTypedArray()
            val temperatureRecord: Array<String =temperatureRecordArray .text.toString().split(",").map { it.trim() }.toTypedArray()

            val textView = "WeekDays \n ${weeklyDaysNumberArray.joinToString(separator = "\n")}"
            val text = "WeekDays \n ${weeklyDaysNumberArray.joinToString(separator = "\n")}"


        }
    }
}